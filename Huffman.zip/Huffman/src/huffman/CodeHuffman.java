package huffman;

public class CodeHuffman {

    private PriorityQueue PriorityQueue;
    private String message;
    private int cnt;
    private TreeHuffman TreeFinal;
    private char[] CharFinalTree;
    private String[] CodeTreeFinal;
    private int TableCountCode = 0;

    public int getCharacterIndex(char key) {
        for (int i = 0; i < CharFinalTree.length; i++) {
            if (key == CharFinalTree[i]) {
                return i;
            }
        }
        return -1;
    }

    public int getCodeIndex(String key) {
        for (int i = 0; i < TableCountCode; i++) {
            if (CodeTreeFinal[i].equals(key)) {
                return i;
            }
        }
        return -1;
    }

    public boolean isInCodeArray(String key) {
        for (int i = 0; i < TableCountCode; i++) {
            if (CodeTreeFinal[i].equals(key)) {
                return true;
            }
        }
        return false;
    }

    public String encode(String message) {
        String MessageEncoded = "";
        for (int i = 0; i < message.length(); i++) {
            if (isInMessage(message.charAt(i))) {
                MessageEncoded = MessageEncoded + CodeTreeFinal[getCharacterIndex(message.charAt(i))];
            } else {
                System.out.println("Character " + message.charAt(i) + " is not in the tree");
                MessageEncoded = "impossible to encode";
                break;
            }
        }
        return MessageEncoded;
    }

    public String decode(String message) {
        String MessageDecoded = "";
        String temp = "";
        for (int i = 0; i < message.length(); i++) {
            temp = temp + message.charAt(i);

            if (isInCodeArray(temp)) {
                MessageDecoded = MessageDecoded + CharFinalTree[getCodeIndex(temp)];
                temp = "";
            }
        }
        if (temp.length() == message.length()) {
            MessageDecoded = "impossible to decode";
        }
        return MessageDecoded;
    }

public CodeHuffman(String message) {
        this.message = message;
        PriorityQueue = new PriorityQueue(message.length());
        CharFinalTree = new char[message.length()];
        CodeTreeFinal = new String[message.length()];
    }

    public void TreeDisplay() {
        TreeFinal.inorder(message.length());
    }

    public void TreeBuild() {
        insertToQueue();
        for (int i = 0; i < cnt - 1; i++) {
            TreeHuffman parent = new TreeHuffman(PriorityQueue.delete(), PriorityQueue.delete());
            parent.root.frequency = parent.root.left.frequency + parent.root.right.frequency;

            PriorityQueue.insert(parent);
        }
        TreeFinal = PriorityQueue.delete();
        TreeDisplay();
    }

    public void insertToQueue() {
        char[] characters = new char[message.length()];
        int insertcnt = 0;
        for (int i = 0; i < message.length(); i++) {
            if (!isRepeated(message.charAt(i), i)) {
                characters[insertcnt] = message.charAt(i);
                insertcnt++;
            }
        }

        for (int i = insertcnt - 1; i >= 0; i--) {
            TreeHuffman tree = new TreeHuffman(characters[i], getFrequency(characters[i]));
            PriorityQueue.insert(tree);
            cnt++;
        }
    }

    public int getFrequency(char c) {
        int cnt = 0;
        for (int i = 0; i < message.length(); i++) {
            if (message.charAt(i) == c) {
                cnt++;
            }
        }
        return cnt;
    }

    public boolean isRepeated(char c, int index) {
        for (int i = index + 1; i < message.length(); i++) {
            if (message.charAt(i) == c) {
                return true;
            }
        }
        return false;
    }

    public boolean isInMessage(char key) {
        for (int i = 0; i < message.length(); i++) {
            if (message.charAt(i) == key) {
                return true;
            }
        }
        return false;
    }

    public void buildCodeTable() {
        String[] CodeTree = TreeFinal.getCodeTree();
        char[] CharTree = TreeFinal.getCharacterTree();

        System.out.println("Code Table: ");

        for (int i = 0; i < CodeTree.length; i++) {
            if (isInMessage(CharTree[i])) {
                System.out.println("Character: " + CharTree[i] + ", has a code of: " + CodeTree[i]);
                CharFinalTree[TableCountCode] = CharTree[i];
                CodeTreeFinal[TableCountCode] = CodeTree[i];
                TableCountCode++;
            }
        }
    }}