package huffman;

public class TreeHuffman {
    public Node root;
    private char[] CharacterTree;
    private String[] CodeTree;
    private int cnt = 0;
    
    private void inorder(Node rootlocal, String code){
        if (rootlocal != null){
            System.out.println("Character: " + rootlocal.character + ", with frequency: " + rootlocal.frequency + ", with code: " + code); 
       CharacterTree[cnt] = rootlocal.character;
       CodeTree[cnt] = code;
       cnt++;
       preorder(rootlocal.left, code + "0");
       preorder (rootlocal.right, code + "1");
        }
    }
    public char[] getCharacterTree(){
        return CharacterTree;
    }
    public String[] getCodeTree(){
        return CodeTree;
    }

    
    public TreeHuffman(char character, int frequency){
        root = new Node();
        root.frequency = frequency;
        root.character = character;
    }
    public TreeHuffman(TreeHuffman leftChild, TreeHuffman rightChild){
        root = new Node();
        root.left = leftChild.root;
        root.right = rightChild.root;          
    }
    private void preorder(Node rootlocal, String code){
        if (rootlocal != null){
            System.out.println("Character: " + rootlocal.character + " ,with frequency: " + rootlocal.frequency+ " ,with code: " + code);
       CharacterTree[cnt] = rootlocal.character;
       CodeTree[cnt] = code;
       cnt++;
       preorder(rootlocal.left, code + "0");
       preorder(rootlocal.right, code + "1");
        }
    }
    public void inorder(int size){
        CharacterTree = new char[size * 2];
        CodeTree = new String[size * 2];
        System.out.println("Displaying contents of the tree: ");
        String code = "";
        inorder(root, code);
    }}
    