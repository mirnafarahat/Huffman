package huffman;

import java.util.Scanner;

public class huffmanMain {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Type your message: ");
        String message = sc.nextLine();
        CodeHuffman huffman = new CodeHuffman(message);
        huffman.TreeBuild();
        huffman.buildCodeTable();
        System.out.println("Type your message to encode: ");
        String encodeThis = sc.nextLine();
        System.out.println("Encoded message for " + encodeThis + " is " + huffman.encode(encodeThis));
        System.out.println ("Type your message to decode: ");
        String decodeThis = sc.nextLine();
        System.out.println("Decoded message for " + decodeThis + " is " + huffman.decode(decodeThis) + "");
    }
    
}
