package huffman;

public class Node {
    public char character;
    public int frequency;
    public Node left;
    public Node right;
    
    public void NodeDisplay() {
        System.out.print("{");
        System.out.print(frequency);
        System.out.print(", ");
        System.out.print("}");
    }
        
    
}
