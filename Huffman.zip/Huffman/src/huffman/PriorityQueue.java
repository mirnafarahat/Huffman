package huffman;

public class PriorityQueue {
    private TreeHuffman[] array;
    private int numitems;
    

    public void insert(TreeHuffman item){
        int i;
        if (!isFull()){
            if (numitems == 0){
                array[numitems++] = item;
                
            }
            else{
                for (i = numitems - 1; i>= 0; i--){
                    if (item.root.frequency > array [i].root.frequency)
                        array [i + 1] = array[i];
                    else
                        break;
                }
                array[i + 1] = item;
                numitems++;
            }
        }
    }

public PriorityQueue(int size){
        array = new TreeHuffman[size];
        numitems = 0;
    }
    public boolean isEmpty() {
        return numitems == 0;
    }
    public boolean isFull(){
        return numitems == array.length;
    }
    public TreeHuffman delete(){
        if (!isEmpty()){
            TreeHuffman temp = array[numitems-1];
            numitems--;
            return temp;
        }
        else { 
            return null;
        }
    }
}